package com.capgemini.HealthCareSystem.services;

import java.util.List;

import com.capgemini.HealthCareSystem.modal.Patient;

public class PatientServiceImpl implements PatientService{

	@Override
	public List<Patient> getAllPatients() {
		// TODO Auto-generated method stub
		return null;
	}

}
