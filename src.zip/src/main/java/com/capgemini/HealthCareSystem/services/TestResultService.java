package com.capgemini.HealthCareSystem.services;

public interface TestResultService {

}
