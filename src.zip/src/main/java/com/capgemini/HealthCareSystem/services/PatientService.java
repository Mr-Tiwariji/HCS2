package com.capgemini.HealthCareSystem.services;

import java.util.List;

import com.capgemini.HealthCareSystem.modal.Patient;

public interface PatientService {
	List<Patient>getAllPatients();

}
