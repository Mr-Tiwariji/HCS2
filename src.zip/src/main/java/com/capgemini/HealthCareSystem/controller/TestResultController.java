package com.capgemini.HealthCareSystem.controller;

import org.springframework.stereotype.Controller;

@Controller
public class TestResultController {

}
